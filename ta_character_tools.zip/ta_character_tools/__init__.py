"""
TA Character Tools - Blender插件主模块
作者: 2025Q3技术美术训练营_江一诺
描述: 插件初始化和注册模块，负责加载所有子模块和注册Blender类
"""

bl_info = {
    "name": "TA Character Tools",
    "author": "2025Q3技术美术训练营_江一诺_Blender脚本作业",
    "version": (1, 0, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > TA Tools",
    "description": "TA",
    "category": "3D View",
}

import bpy
from . import utils
from . import properties
from . import operators_material
from . import operators_armature
from . import operators_animation
from . import operators_export
from . import ui

def register():
    # 首先注册PropertyGroup类
    bpy.utils.register_class(properties.TAMaterialGroupItem)
    
    # 然后注册所有Operator类
    bpy.utils.register_class(operators_material.TA_OT_LoadMaterialJson)
    bpy.utils.register_class(operators_material.TA_OT_SelectGroupObjects)
    bpy.utils.register_class(operators_material.TA_OT_CleanMaterials)
    
    bpy.utils.register_class(operators_armature.TA_OT_RotateReferenceObject)
    bpy.utils.register_class(operators_armature.TA_OT_MirrorCharacterX)
    bpy.utils.register_class(operators_armature.TA_OT_FixMeshData)
    bpy.utils.register_class(operators_armature.TA_OT_MatchEditPose)
    
    bpy.utils.register_class(operators_animation.TA_OT_ShrinkDummyAnim)
    bpy.utils.register_class(operators_animation.TA_OT_FixDummyAnimLocation)
    bpy.utils.register_class(operators_animation.TA_OT_CopyBonePoseGenAnim)
    bpy.utils.register_class(operators_animation.TA_OT_GenRigAnim)
    
    bpy.utils.register_class(operators_export.TA_OT_ExportFbx)
    
    # 然后注册UIList类
    bpy.utils.register_class(ui.TAMaterialGroupUIList)
    
    # 最后注册Panel类
    bpy.utils.register_class(ui.TACharacterToolsPanel)
    
    # 注册Scene属性
    bpy.types.Scene.ta_character_name = bpy.props.StringProperty(
        name="Character Name",
        description="角色编号",
        update=utils.update_character_collection
    )
    bpy.types.Scene.ta_character_collection = bpy.props.StringProperty(
        name="角色",
        update=utils.sync_character_name
    )
    bpy.types.Scene.ta_reference_object = bpy.props.StringProperty(name="参考对象")
    bpy.types.Scene.ta_material_info_path = bpy.props.StringProperty(name="Material Info Path", subtype='DIR_PATH')
    bpy.types.Scene.ta_project_path = bpy.props.StringProperty(
        name="项目路径", subtype='DIR_PATH', update=utils.update_project_path
    )
    bpy.types.Scene.ta_model_path = bpy.props.StringProperty(name="模型路径", subtype='FILE_PATH')
    bpy.types.Scene.ta_is_anim = bpy.props.BoolProperty(
        name="is_anim", default=False, update=utils.update_is_anim
    )
    bpy.types.Scene.ta_material_groups = bpy.props.CollectionProperty(type=properties.TAMaterialGroupItem)
    bpy.types.Scene.ta_material_group_index = bpy.props.IntProperty(name="分组索引", default=0)
    bpy.types.Scene.ta_material_list = []
    bpy.types.Scene.ta_saved_material_assignments = bpy.props.StringProperty(
        name="Saved Material Assignments",
        default=""
    )
    bpy.types.Scene.ta_dummy_animation = bpy.props.PointerProperty(
        name="Dummy动画对象",
        type=bpy.types.Object,
        description="选择一个Dummy对象来缩放其动画"
    )

def unregister():
    # 删除Scene属性
    del bpy.types.Scene.ta_dummy_animation
    del bpy.types.Scene.ta_saved_material_assignments
    del bpy.types.Scene.ta_material_list
    del bpy.types.Scene.ta_material_group_index
    del bpy.types.Scene.ta_material_groups
    del bpy.types.Scene.ta_is_anim
    del bpy.types.Scene.ta_model_path
    del bpy.types.Scene.ta_project_path
    del bpy.types.Scene.ta_material_info_path
    del bpy.types.Scene.ta_reference_object
    del bpy.types.Scene.ta_character_collection
    del bpy.types.Scene.ta_character_name
    
    # 注销Panel类
    bpy.utils.unregister_class(ui.TACharacterToolsPanel)
    
    # 注销UIList类
    bpy.utils.unregister_class(ui.TAMaterialGroupUIList)
    
    # 注销所有Operator类
    bpy.utils.unregister_class(operators_export.TA_OT_ExportFbx)
    bpy.utils.unregister_class(operators_animation.TA_OT_GenRigAnim)
    bpy.utils.unregister_class(operators_animation.TA_OT_CopyBonePoseGenAnim)
    bpy.utils.unregister_class(operators_animation.TA_OT_FixDummyAnimLocation)
    bpy.utils.unregister_class(operators_animation.TA_OT_ShrinkDummyAnim)
    bpy.utils.unregister_class(operators_armature.TA_OT_MatchEditPose)
    bpy.utils.unregister_class(operators_armature.TA_OT_FixMeshData)
    bpy.utils.unregister_class(operators_material.TA_OT_CleanMaterials)
    bpy.utils.unregister_class(operators_armature.TA_OT_MirrorCharacterX)
    bpy.utils.unregister_class(operators_armature.TA_OT_RotateReferenceObject)
    bpy.utils.unregister_class(operators_material.TA_OT_SelectGroupObjects)
    bpy.utils.unregister_class(operators_material.TA_OT_LoadMaterialJson)
    
    # 注销PropertyGroup类
    bpy.utils.unregister_class(properties.TAMaterialGroupItem)

if __name__ == "__main__":
    register() 