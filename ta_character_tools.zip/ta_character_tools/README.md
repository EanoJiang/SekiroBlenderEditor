# TA Character Tools

一个用于角色工具开发的Blender插件，包含材质管理、骨骼操作、动画处理和模型导出等功能。

## 功能模块

### 1. 材质管理

- 加载材质JSON文件
- 材质分组和分配
- 清理重复材质球

### 2. 骨骼操作

- 旋转参考对象
- 角色X轴镜像
- 一键修正骨骼数据
- 根据参考物体重置edit pose

### 3. 动画处理

- 缩放dummy动画
- 修复dummy动画导入时的缩放问题
- 复制bone pose生成骨骼动画

### 4. 模型导出

- 导出FBX和贴图
- 支持动画和非动画模式

## 使用方法

1. 在3D视图的侧边栏中找到 "TA Tools" 面板
2. 设置角色名称和集合
3. 选择参考对象
4. 根据需要执行相应的操作

## 文件结构

```
ta_character_tools/
├── __init__.py          # 插件入口文件
├── bl_info.py           # 插件信息
├── utils.py             # 工具函数
├── properties.py        # 属性组定义
├── operators_material.py # 材质相关操作器
├── operators_armature.py # 骨骼相关操作器
├── operators_animation.py # 动画相关操作器
├── operators_export.py  # 导出相关操作器
├── ui.py               # UI界面类
└── README.md           # 说明文档
```

