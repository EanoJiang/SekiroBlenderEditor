"""
TA Character Tools - 动画操作模块
作者: 2025Q3技术美术训练营_江一诺
描述: 处理角色动画相关操作，包括Dummy动画缩放、骨骼动画生成等
"""

import bpy

class TA_OT_ShrinkDummyAnim(bpy.types.Operator):
    bl_idname = "ta.shrink_dummy_anim"
    bl_label = "缩放dummy动画"
    bl_description = "将Dummy动画对象的三个轴缩放都设为-0.01，并应用到所有动画帧"
    
    def execute(self, context):
        dummy_obj = context.scene.ta_dummy_animation
        if not dummy_obj:
            self.report({'WARNING'}, "未选择Dummy动画对象")
            return {'CANCELLED'}
        
        # 获取动画数据
        if not dummy_obj.animation_data or not dummy_obj.animation_data.action:
            self.report({'WARNING'}, "选择的对象没有动画数据")
            return {'CANCELLED'}
        
        action = dummy_obj.animation_data.action
        fcurves = action.fcurves
        
        # 查找缩放相关的F-Curves
        scale_curves = []
        for fc in fcurves:
            if 'scale' in fc.data_path.lower():
                scale_curves.append(fc)
        
        if not scale_curves:
            self.report({'WARNING'}, "未找到缩放相关的动画曲线")
            return {'CANCELLED'}
        
        # 修改所有缩放关键帧的值为-0.01
        modified_count = 0
        for fc in scale_curves:
            for keyframe in fc.keyframe_points:
                keyframe.co[1] = -0.01  # 将Y值（缩放值）设为-0.01
                modified_count += 1
        
        self.report({'INFO'}, f"已修改{modified_count}个缩放关键帧，缩放值设为-0.01")
        return {'FINISHED'}


class TA_OT_FixDummyAnimLocation(bpy.types.Operator):
    bl_idname = "ta.fix_dummy_anim_location"
    bl_label = "修复原有dummy动画导入时产生的缩放"
    bl_description = "根据刚导入时获取到的缩放比(这里是-0.025)，修正dummy动画的位移关键帧"
    
    def execute(self, context):
        dummy_obj = context.scene.ta_dummy_animation
        if not dummy_obj:
            self.report({'WARNING'}, "未选择Dummy动画对象")
            return {'CANCELLED'}
        if not dummy_obj.animation_data or not dummy_obj.animation_data.action:
            self.report({'WARNING'}, "选择的对象没有动画数据")
            return {'CANCELLED'}
        action = dummy_obj.animation_data.action
        fcurves = action.fcurves
        # 原始缩放和目标缩放
        original_scale = -0.025
        target_scale = -0.01
        scale_ratio = target_scale / original_scale  # 0.4
        # 查找位置相关的F-Curves
        loc_curves = [fc for fc in fcurves if 'location' in fc.data_path.lower()]
        if not loc_curves:
            self.report({'WARNING'}, "未找到位移相关的动画曲线")
            return {'CANCELLED'}
        modified_count = 0
        for fc in loc_curves:
            for keyframe in fc.keyframe_points:
                keyframe.co[1] *= scale_ratio
                modified_count += 1
        self.report({'INFO'}, f"已将{modified_count}个位移关键帧修正缩放")
        return {'FINISHED'}


class TA_OT_CopyBonePoseGenAnim(bpy.types.Operator):
    bl_idname = "ta.copy_bone_pose_gen_anim"
    bl_label = "复制bone pose生成骨骼动画"
    bl_description = "复制bone pose并生成骨骼动画"
    
    def get_dummy_scale_factor(self, dummy_obj):
        """获取dummy对象的缩放因子"""
        # 查找根对象（没有父对象的对象）
        def find_root(obj):
            if obj.parent is None:
                return obj
            return find_root(obj.parent)
        
        root_obj = find_root(dummy_obj)
        if not root_obj:
            return 1.0  # 默认无缩放
        
        # 检查根对象是否有缩放动画
        if root_obj.animation_data and root_obj.animation_data.action:
            action = root_obj.animation_data.action
            for fc in action.fcurves:
                if 'scale' in fc.data_path.lower():
                    # 获取第一个关键帧的缩放值
                    if fc.keyframe_points:
                        return fc.keyframe_points[0].co[1]
        return 1.0  # 默认无缩放
    
    def get_dummy_hierarchy(self, dummy_obj):
        """获取dummy对象的层级结构，以根对象为中心，递归获取所有子级"""
        # 查找根对象（没有父对象的对象）
        def find_root(obj):
            if obj.parent is None:
                return obj
            return find_root(obj.parent)
        
        root_dummy = find_root(dummy_obj)
        if not root_dummy:
            self.report({'WARNING'}, "未找到根对象")
            return []
        
        hierarchy = []
        
        # 递归函数：获取对象及其所有子级
        def add_object_and_children(obj, depth=0, parent_path=""):
            if not obj:
                return
            
            # 构建完整路径
            if parent_path:
                full_path = f"{parent_path}.{obj.name}"
            else:
                full_path = obj.name
            
            # 添加当前对象
            hierarchy.append((obj, full_path, depth))
            
            # 递归添加所有子级
            for child in obj.children:
                add_object_and_children(child, depth + 1, full_path)
        
        # 从根对象开始，递归获取所有子级
        add_object_and_children(root_dummy, 0)
        
        return hierarchy
    
    def calculate_relative_position(self, child_obj, parent_obj, scale_factor):
        """计算相对位置，考虑缩放因子（根对象不应用缩放）"""
        # 如果是根对象，不应用缩放因子
        if child_obj.parent is None:
            if not parent_obj:
                return child_obj.location
            # 获取父对象的旋转矩阵
            parent_rotation = parent_obj.rotation_euler.to_matrix()
            # 计算相对位置（考虑父对象的旋转）
            relative_pos = child_obj.location - parent_obj.location
            rotated_relative = parent_rotation.inverted() @ relative_pos
            return rotated_relative
        
        # 其他数据点正常应用缩放因子
        if not parent_obj:
            return child_obj.location * scale_factor
        
        # 获取父对象的旋转矩阵
        parent_rotation = parent_obj.rotation_euler.to_matrix()
        
        # 计算相对位置（考虑父对象的旋转）
        relative_pos = child_obj.location - parent_obj.location
        rotated_relative = parent_rotation.inverted() @ relative_pos
        
        return rotated_relative * scale_factor
    
    def execute(self, context):
        # 获取角色骨架和dummy动画对象
        char_name = context.scene.ta_character_collection
        dummy_obj = context.scene.ta_dummy_animation
        
        if not char_name:
            self.report({'WARNING'}, "未选择角色")
            return {'CANCELLED'}
        
        if not dummy_obj:
            self.report({'WARNING'}, "未选择Dummy动画对象")
            return {'CANCELLED'}
        
        # 获取角色集合
        role_collection = bpy.data.collections.get(char_name)
        if not role_collection:
            self.report({'WARNING'}, f"未找到角色集合: {char_name}")
            return {'CANCELLED'}
        
        # 获取角色骨架对象
        role_armature = None
        for obj in role_collection.objects:
            if obj.type == 'ARMATURE':
                role_armature = obj
                break
        
        if not role_armature:
            self.report({'WARNING'}, "角色集合中未找到骨架对象")
            return {'CANCELLED'}
        
        # 检查dummy对象是否有动画数据
        if not dummy_obj.animation_data or not dummy_obj.animation_data.action:
            self.report({'WARNING'}, "Dummy对象没有动画数据")
            return {'CANCELLED'}
        
        action = dummy_obj.animation_data.action
        if not action.fcurves:
            self.report({'WARNING'}, "动画数据中没有关键帧")
            return {'CANCELLED'}
        
        try:
            # 获取dummy缩放因子
            scale_factor = self.get_dummy_scale_factor(dummy_obj)
            self.report({'INFO'}, f"检测到dummy缩放因子: {scale_factor}")
            
            # 获取动画的时间范围
            frame_start = int(action.frame_range[0])
            frame_end = int(action.frame_range[1])
            
            # 获取角色骨架的pose bones
            pose_bones = role_armature.pose.bones
            
            # 创建新的动画action
            new_action = bpy.data.actions.new(name=f"{dummy_obj.name}_to_{role_armature.name}")
            
            # 为角色骨架分配动画数据
            if not role_armature.animation_data:
                role_armature.animation_data_create()
            role_armature.animation_data.action = new_action
            
            # 自动切换到POSE模式
            bpy.context.view_layer.objects.active = role_armature
            bpy.ops.object.mode_set(mode='POSE')
            
            # 获取dummy层级结构
            dummy_hierarchy = self.get_dummy_hierarchy(dummy_obj)
            
            # 创建骨骼名称映射
            bone_name_mapping = {}
            for child, full_name, depth in dummy_hierarchy:
                bone_name = child.name
                # 移除改名逻辑，保持原始名称
                bone_name_mapping[full_name] = bone_name
            
            # 打印匹配信息
            matched_count = 0
            for child, full_name, depth in dummy_hierarchy:
                bone_name = bone_name_mapping[full_name]
                # 检查是否在pose_bones中找到匹配
                for pb in pose_bones:
                    if pb.name == bone_name:
                        self.report({'INFO'}, f"匹配: {child.name} -> {bone_name}")
                        matched_count += 1
                        break
            
            self.report({'INFO'}, f"单帧匹配总数: {matched_count}")
            
            # 预先为所有目标骨骼创建F-Curve
            fcurve_dict = {}
            for pb in pose_bones:
                for prop, count in [('location', 3), ('rotation_euler', 3)]:
                    for i in range(count):
                        data_path = f'pose.bones["{pb.name}"].{prop}'
                        fc = new_action.fcurves.find(data_path, index=i)
                        if not fc:
                            fc = new_action.fcurves.new(data_path=data_path, index=i)
                        fcurve_dict[(pb.name, prop, i)] = fc
            
            processed_frames = 0
            matched_bones_count = 0  # 实际匹配上的骨骼数量
            matched_bones_set = set()  # 用于记录已匹配的骨骼名称
            
            for frame in range(frame_start, frame_end + 1):
                context.scene.frame_set(frame)
                dummy_obj.update_tag()
                
                for child, full_name, depth in dummy_hierarchy:
                    bone_name = bone_name_mapping[full_name]
                    pose_bone = None
                    for pb in pose_bones:
                        if pb.name == bone_name:
                            pose_bone = pb
                            break
                    
                    if pose_bone:
                        # 计算相对位置
                        relative_location = self.calculate_relative_position(child, child.parent, scale_factor)
                        
                        # 获取旋转（直接使用dummy的旋转）
                        rotation = child.rotation_euler
                        
                        # 设置关键帧（坐标轴重新映射）
                        # X轴位置使用原始Y值
                        fcurve_dict[(pose_bone.name, 'location', 0)].keyframe_points.insert(frame, relative_location[1])
                        # Y轴位置使用原始Z值
                        fcurve_dict[(pose_bone.name, 'location', 1)].keyframe_points.insert(frame, relative_location[2])
                        # Z轴位置使用原始X值
                        fcurve_dict[(pose_bone.name, 'location', 2)].keyframe_points.insert(frame, relative_location[0])
                        
                        # 旋转也重新映射
                        fcurve_dict[(pose_bone.name, 'rotation_euler', 0)].keyframe_points.insert(frame, rotation[1])
                        fcurve_dict[(pose_bone.name, 'rotation_euler', 1)].keyframe_points.insert(frame, rotation[2])
                        fcurve_dict[(pose_bone.name, 'rotation_euler', 2)].keyframe_points.insert(frame, rotation[0])
                        
                        # 记录匹配的骨骼名称
                        matched_bones_set.add(pose_bone.name)
                
                processed_frames += 1
                if processed_frames % 10 == 0:
                    self.report({'INFO'}, f"处理进度: {processed_frames}/{frame_end - frame_start + 1} 帧")
            
            # 计算实际匹配的骨骼数量
            matched_bones_count = len(matched_bones_set)
            
            context.scene.frame_start = frame_start
            context.scene.frame_end = frame_end
            
            # 复制完切回OBJECT模式
            bpy.ops.object.mode_set(mode='OBJECT')
            self.report({'INFO'}, f"动画复制完成！处理了 {processed_frames} 帧，匹配了 {matched_bones_count} 个骨骼")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"复制动画时发生错误: {str(e)}")
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except:
                pass
            return {'CANCELLED'}


class TA_OT_GenRigAnim(bpy.types.Operator):
    bl_idname = "ta.gen_rig_anim"
    bl_label = "根据dummy动画生成骨骼动画"
    def execute(self, context):
        self.report({'INFO'}, "还没写")
        return {'FINISHED'} 