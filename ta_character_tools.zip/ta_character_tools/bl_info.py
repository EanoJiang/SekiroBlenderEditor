"""
TA Character Tools - Blender插件
作者: 2025Q3技术美术训练营_江一诺
描述: TA角色工具插件，提供角色建模、材质、骨骼和动画处理功能
"""

bl_info = {
    "name": "TA Character Tools",
    "author": "2025Q3技术美术训练营_江一诺_Blender脚本作业",
    "version": (1, 0, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > TA Tools",
    "description": "TA",
    "category": "3D View",
} 