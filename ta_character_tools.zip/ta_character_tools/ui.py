"""
TA Character Tools - 用户界面模块
作者: 2025Q3技术美术训练营_江一诺
描述: 定义插件的用户界面，包括面板和UI列表组件
"""

import bpy

class TAMaterialGroupUIList(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        # 使用固定比例分割布局
        split = layout.split(factor=0.4)  # 左边占40%
        
        # 第一列：部件名
        # 创建容器
        row1 = split.column()
        row1.scale_y = 1.0
        # 使用box创建统一的背景和边框
        box = row1.box()
        box.scale_y = 0.8
        
        # 在box内创建按钮
        sub = box.row(align=True)
        sub.alignment = 'CENTER'  # 文本居中
        
        # 使用operator_context来确保立即执行
        sub.operator_context = 'EXEC_DEFAULT'
        # 创建选择按钮
        op = sub.operator("ta.select_group_objects", text=item.name, emboss=False)
        if op is not None:
            op.group_name = item.name
            op.index = index
            
        # 剩余空间分割
        split2 = split.split(factor=0.4)  # 中间占24%（0.4 * 0.6），右边占36%（0.6 * 0.6）
        
        # 第二列：MTD（只读显示）
        row2 = split2.row()
        row2.label(text=item.mtd)
        
        # 第三列：材质选择
        row3 = split2.row()
        row3.prop_search(item, "material", bpy.data, "materials", text="")

class TACharacterToolsPanel(bpy.types.Panel):
    bl_label = "TA Character Tools"
    bl_idname = "VIEW3D_PT_ta_character_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TA Tools"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        layout.prop(scene, "ta_character_name", text="Character Name")
        row = layout.row(align=True)
        row.prop_search(scene, "ta_character_collection", bpy.data, "collections", text="角色")
        row.operator("ta.mirror_character_x", text="X轴镜像并应用缩放", icon='MOD_MIRROR')
        row = layout.row(align=True)
        row.prop_search(scene, "ta_reference_object", bpy.data, "objects", text="参考对象")
        row.operator("ta.rotate_reference_object", text="旋转参考对象", icon='CON_ROTLIKE')

        # 1. 材质
        layout.label(text="1.材质")
        row = layout.row()
        row.prop(scene, "ta_material_info_path", text="Material Info Path")
        row.operator("ta.load_material_json", text="加载材质json")
        layout.template_list("TAMaterialGroupUIList", "", scene, "ta_material_groups", scene, "ta_material_group_index", rows=6)
        layout.operator("ta.clean_materials", text="Clean Duplicated Materials & Empty Material Slot")

        # 2. 骨骼
        layout.label(text="2.骨骼")
        layout.operator("ta.fix_mesh_data", text="一键修正骨骼数据")
        layout.operator("ta.match_edit_pose", text="根据参考物体,重置edit pose")

        # 3. 动画
        layout.label(text="3.动画")
        
        # Dummy动画对象选择
        layout.prop_search(scene, "ta_dummy_animation", bpy.data, "objects", text="Dummy动画对象:")
        layout.operator("ta.shrink_dummy_anim", text="缩放dummy动画")
        layout.operator("ta.fix_dummy_anim_location", text="修复原有dummy动画导入时产生的缩放")
        layout.operator("ta.copy_bone_pose_gen_anim", text="复制bone pose生成骨骼动画")

        # 4. 模型导出
        layout.label(text="4.模型导出")
        layout.prop(scene, "ta_project_path", text="项目路径")
        layout.prop(scene, "ta_model_path", text="模型路径")
        layout.prop(scene, "ta_is_anim", text="is_anim")
        layout.operator("ta.export_fbx", text="导出Fbx和贴图") 