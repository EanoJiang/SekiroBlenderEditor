"""
TA Character Tools - 材质操作模块
作者: 2025Q3技术美术训练营_江一诺
描述: 处理角色材质相关操作，包括材质JSON加载、材质分配、清理等
"""

import bpy
import os
import json

class TA_OT_LoadMaterialJson(bpy.types.Operator):
    bl_idname = "ta.load_material_json"
    bl_label = "加载材质json"
    def execute(self, context):
        dir_path = context.scene.ta_material_info_path
        char_id = context.scene.ta_character_collection.strip()  # 角色编号
        if not os.path.isdir(dir_path):
            self.report({'ERROR'}, "请选择有效的文件夹")
            return {'CANCELLED'}
        if not char_id:
            self.report({'ERROR'}, "请先选择角色编号")
            return {'CANCELLED'}
            
        # 获取保存的材质分配数据
        saved_assignments = {}
        if context.scene.ta_saved_material_assignments:
            try:
                saved_assignments = json.loads(context.scene.ta_saved_material_assignments)
            except:
                pass
                
        # 清空旧数据
        context.scene.ta_material_groups.clear()
        mat_dict = {}  # key: 材质名, value: [编号1, 编号2, ...]
        mtd_dict = {}  # key: 材质名, value: mtd原始路径
        
        # 统计信息
        total_entries = 0
        loaded_entries = 0
        
        # 只查找对应角色编号的json文件
        target_json = f"{char_id}.json"
        json_path = os.path.join(dir_path, target_json)
        
        if not os.path.exists(json_path):
            self.report({'ERROR'}, f"未找到角色{char_id}对应的json文件: {target_json}")
            return {'CANCELLED'}
            
        # 只读取目标json文件
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                for entry in data:
                    total_entries += 1
                    try:
                        mtd_path = entry.get('MTD', '')
                        part_name = entry.get('Name', '')
                        
                        # 跳过没有必要信息的条目
                        if not mtd_path or not part_name:
                            continue
                            
                        # 提取MTD文件名（不带路径和扩展名）
                        mtd_filename = os.path.basename(mtd_path)
                        mtd = os.path.splitext(mtd_filename)[0]
                        
                        # 直接添加所有对应关系，不再进行过滤
                        if mtd not in mat_dict:
                            mat_dict[mtd] = []
                            mtd_dict[mtd] = mtd_filename
                        
                        # 避免重复添加相同的部件名
                        if part_name not in mat_dict[mtd]:
                            mat_dict[mtd].append(part_name)
                            loaded_entries += 1
                            
                    except Exception as e:
                        self.report({'WARNING'}, f"处理条目时出错: {str(e)}")
                        continue
                        
        except Exception as e:
            self.report({'ERROR'}, f"{target_json} 解析失败: {e}")
            return {'CANCELLED'}
        
        # 填充到CollectionProperty并应用保存的材质分配
        for mtd, part_list in mat_dict.items():
            group = context.scene.ta_material_groups.add()
            group.name = ','.join(part_list)
            group.mtd = mtd_dict[mtd]
            
            # 使用保存的材质分配
            parts_key = ','.join(sorted(part_list))
            if parts_key in saved_assignments:
                saved_material = saved_assignments[parts_key]
                if saved_material in bpy.data.materials:
                    group.material = saved_material
                    if hasattr(group, 'apply_material'):
                        group.apply_material(context)
        
        self.report({'INFO'}, f"已加载 {loaded_entries}/{total_entries} 个对应关系")
        return {'FINISHED'}

class TA_OT_SelectGroupObjects(bpy.types.Operator):
    bl_idname = "ta.select_group_objects"
    bl_label = "选择分组物体"
    
    group_name: bpy.props.StringProperty()
    index: bpy.props.IntProperty()
    
    def execute(self, context):
        # 设置激活项
        context.scene.ta_material_group_index = self.index

        # 彻底清除所有对象的选中状态
        for obj in bpy.data.objects:
            obj.select_set(False)

        # 获取当前collection
        col_name = context.scene.ta_character_collection
        if col_name in bpy.data.collections:
            col = bpy.data.collections[col_name]
            part_names = self.group_name.split(',')
            selected_objects = []

            # 选中匹配的物体
            for obj in col.objects:
                for part in part_names:
                    if part and part in obj.name:
                        obj.select_set(True)
                        selected_objects.append(obj)

            # 设置活动物体
            if selected_objects:
                context.view_layer.objects.active = selected_objects[0]

        # 强制刷新所有3D视图
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

        # 选中后强制更新视图层
        bpy.context.view_layer.update()

        # 视图聚焦（可选，防止报错）
        try:
            for window in bpy.context.window_manager.windows:
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D':
                        for region in area.regions:
                            if region.type == 'WINDOW':
                                override = {
                                    'window': window,
                                    'screen': window.screen,
                                    'area': area,
                                    'region': region,
                                    'scene': context.scene,
                                    'view_layer': context.view_layer,
                                }
                                bpy.ops.view3d.view_selected(override, use_all_regions=False)
        except Exception as e:
            print(f"视图聚焦失败: {e}")

        return {'FINISHED'}

class TA_OT_CleanMaterials(bpy.types.Operator):
    bl_idname = "ta.clean_materials"
    bl_label = "清理重复材质球"   
    bl_description = "删除带.001、.002等后缀的材质"
    def execute(self, context):
        # 删除带.001、.002等后缀的材质
        remove_count = 0
        for mat in list(bpy.data.materials):
            if mat.name.endswith(tuple([f'.{str(i).zfill(3)}' for i in range(1, 100)])):
                bpy.data.materials.remove(mat)
                remove_count += 1
        self.report({'INFO'}, f"已删除{remove_count}个带.001.002后缀材质球")
        return {'FINISHED'} 