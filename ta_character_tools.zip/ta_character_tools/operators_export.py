"""
TA Character Tools - 导出操作模块
作者: 2025Q3技术美术训练营_江一诺
描述: 处理模型和动画的FBX导出功能，包括贴图导出和路径管理
"""

import bpy
import os
import json
import re
import math
import shutil
from . import utils

class TA_OT_ExportFbx(bpy.types.Operator):
    bl_idname = "ta.export_fbx"
    bl_label = "导出Fbx"
    bl_description = "根据角色名导出对应贴图到Fbx/Textures目录下"
    
    def auto_generate_model_path(self, context):
        """根据项目路径和角色名自动生成模型路径"""
        project_path = context.scene.ta_project_path
        char_name = context.scene.ta_character_name
        is_anim = context.scene.ta_is_anim
        
        if not project_path or not char_name or char_name == 'None':
            return None
        
        # 将Blender路径转换为绝对路径
        abs_project_path = bpy.path.abspath(project_path)
        
        # 获取角色前缀（前5位）
        char_prefix = char_name[:5] if len(char_name) >= 5 else char_name
        
        if is_anim:
            # 动画导出路径：项目路径/角色前缀/Fbx/Animation/角色名@动画标识.fbx
            # 需要从动画数据中获取动画标识
            animation_id = self.get_animation_identifier(context)
            model_path = os.path.join(abs_project_path, char_prefix, "Fbx", "Animation", f"{char_name}@{animation_id}.fbx")
        else:
            # 模型导出路径：项目路径/角色前缀/Fbx/角色名.fbx
            model_path = os.path.join(abs_project_path, char_prefix, "Fbx", f"{char_name}.fbx")
        
        return os.path.normpath(model_path)
    
    def get_animation_identifier(self, context):
        """获取动画标识符"""
        # 尝试从当前选中的动画对象获取动画标识
        dummy_obj = context.scene.ta_dummy_animation
        if dummy_obj and dummy_obj.animation_data and dummy_obj.animation_data.action:
            action_name = dummy_obj.animation_data.action.name
            # 从动作名称中提取动画标识
            # 例如：从 "a000_003006" 中提取标识
            match = re.search(r'a\d+_\d+', action_name)
            if match:
                return match.group(0)
        
        # 如果没有找到，使用默认标识
        return "a000_000000"

    def validate_export_settings(self, context):
        """验证导出设置"""
        project_path = context.scene.ta_project_path
        char_name = context.scene.ta_character_name
        
        if not project_path:
            self.report({'ERROR'}, "请设置项目路径")
            return False
        
        # 将Blender路径转换为绝对路径
        abs_project_path = bpy.path.abspath(project_path)
        
        if not os.path.exists(abs_project_path):
            self.report({'ERROR'}, f"项目路径不存在: {abs_project_path}")
            return False
            
        if not char_name or char_name == 'None':
            self.report({'ERROR'}, "请先选择角色")
            return False
            
        return True
    
    def prepare_export_directories(self, context):
        """准备导出目录"""
        project_path = context.scene.ta_project_path
        char_name = context.scene.ta_character_name
        char_prefix = char_name[:5] if len(char_name) >= 5 else char_name
        
        # 将Blender路径转换为绝对路径
        abs_project_path = bpy.path.abspath(project_path)
        
        # 创建FBX目录
        fbx_dir = os.path.join(abs_project_path, char_prefix, "Fbx")
        if not os.path.exists(fbx_dir):
            os.makedirs(fbx_dir, exist_ok=True)
        
        # 创建贴图目录
        textures_dir = os.path.join(fbx_dir, "Textures")
        if not os.path.exists(textures_dir):
            os.makedirs(textures_dir, exist_ok=True)
        
        # 如果是动画，创建Animation目录
        if context.scene.ta_is_anim:
            animation_dir = os.path.join(fbx_dir, "Animation")
            if not os.path.exists(animation_dir):
                os.makedirs(animation_dir, exist_ok=True)
        
        return True
    
    def select_character_objects(self, context):
        """选择角色集合中的所有对象"""
        char_name = context.scene.ta_character_name
        collection = bpy.data.collections.get(char_name)
        
        if not collection:
            self.report({'WARNING'}, f"未找到角色集合: {char_name}")
            return False
        
        # 取消所有选择
        for obj in bpy.context.view_layer.objects:
            obj.select_set(False)
        
        # 选择角色集合中的所有对象
        for obj in collection.objects:
            obj.select_set(True)
        
        # 设置活动对象
        if collection.objects:
            bpy.context.view_layer.objects.active = collection.objects[0]
        
        return True
    
    def unpack_and_export_textures(self, context, char_name):
        """解包贴图并导出到指定目录"""
        project_path = context.scene.ta_project_path
        char_prefix = char_name[:5] if len(char_name) >= 5 else char_name
        
        # 将Blender路径转换为绝对路径
        abs_project_path = bpy.path.abspath(project_path)
        textures_dir = os.path.join(abs_project_path, char_prefix, "Fbx", "Textures")
        
        # 1. 解包所有贴图
        try:
            bpy.ops.file.unpack_all(method='USE_LOCAL')
        except Exception as e:
            print(f"解包贴图时出错: {e}")
        
        # 2. 收集并导出角色相关贴图
        exported_count = 0
        exported_files = set()
        
        for image in bpy.data.images:
            # 检查图片是否与角色相关
            if not self.is_image_related_to_character(image, char_name):
                continue
            
            # 获取图片基础名称（去除后缀）
            base_name = self.get_image_base_name(image.name)
            
            # 避免重复导出
            if base_name in exported_files:
                continue
            
            # 导出图片
            if self.export_single_texture(image, textures_dir, base_name):
                exported_files.add(base_name)
                exported_count += 1
        
        return exported_count
    
    def is_image_related_to_character(self, image, char_name):
        """检查图片是否与角色相关"""
        # 检查图片名称中是否包含角色ID
        if char_name in image.name:
            return True
        
        # 检查图片是否被角色集合中的对象使用
        collection = bpy.data.collections.get(char_name)
        if collection:
            for obj in collection.objects:
                if obj.type == 'MESH' and obj.data:
                    for material_slot in obj.material_slots:
                        if material_slot.material and material_slot.material.node_tree:
                            for node in material_slot.material.node_tree.nodes:
                                if node.type == 'TEX_IMAGE' and node.image == image:
                                    return True
        
        return False
    
    def get_image_base_name(self, image_name):
        """获取图片基础名称，去除数字后缀"""
        # 移除 .001, .002 等后缀
        base_name = re.sub(r'\.\d{3,}$', '', image_name)
        return base_name
    
    def export_single_texture(self, image, target_dir, base_name):
        """导出单个贴图（避免重复扩展名）"""
        try:
            # 确定文件扩展名
            if image.file_format == 'PNG':
                ext = '.png'
            elif image.file_format == 'JPEG':
                ext = '.jpg'
            else:
                ext = '.png'  # 默认PNG

            # 检查base_name是否已经有扩展名（不区分大小写）
            lower_name = base_name.lower()
            if lower_name.endswith('.png') or lower_name.endswith('.jpg'):
                target_path = os.path.join(target_dir, base_name)
            else:
                target_path = os.path.join(target_dir, base_name + ext)

            # 如果是打包的图片，直接保存
            if image.packed_file is not None:
                image.filepath_raw = target_path
                image.save()
                return True

            # 如果是外部文件，复制文件
            if image.filepath:
                src_path = bpy.path.abspath(image.filepath)
                if os.path.exists(src_path):
                    shutil.copy2(src_path, target_path)
                    return True

            return False

        except Exception as e:
            print(f"导出贴图失败 {image.name}: {e}")
            return False

    def execute(self, context):
        # 验证导出设置
        if not self.validate_export_settings(context):
            return {'CANCELLED'}
        
        # 自动生成模型路径
        model_path = self.auto_generate_model_path(context)
        if not model_path:
            self.report({'ERROR'}, "无法生成模型路径，请检查项目路径和角色设置")
            return {'CANCELLED'}
        
        # 准备导出目录
        if not self.prepare_export_directories(context):
            return {'CANCELLED'}
        
        # 选择角色对象
        if not self.select_character_objects(context):
            return {'CANCELLED'}
        
        # 导出贴图
        char_name = context.scene.ta_character_name
        exported_textures = self.unpack_and_export_textures(context, char_name)
        
        # 导出FBX
        is_anim = context.scene.ta_is_anim
        
        try:
            if is_anim:
                # 勾选is_anim：仅导出ARMATURE，导出动画
                # 注意：不勾选NLA Strips和All Actions，避免卡顿
                bpy.ops.export_scene.fbx(
                    filepath=model_path,
                    use_selection=True,
                    object_types={'ARMATURE'},
                    bake_anim=True,
                    bake_anim_use_all_actions=False,  # 不勾选，避免卡顿
                    bake_anim_use_nla_strips=False,    # 不勾选，避免卡顿
                    bake_anim_force_startend_keying=True,
                    bake_anim_step=1.0,
                    bake_anim_simplify_factor=1.0,
                    add_leaf_bones=False,
                    use_metadata=True
                )
            else:
                # 不勾选is_anim：导出MESH和ARMATURE，不导出动画
                bpy.ops.export_scene.fbx(
                    filepath=model_path,
                    use_selection=True,
                    object_types={'MESH', 'ARMATURE'},
                    bake_anim=False,
                    add_leaf_bones=False,
                    use_metadata=True
                )
            
            self.report({'INFO'}, f"导出完成！FBX: {model_path}, 贴图: {exported_textures} 个")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"导出FBX失败: {e}")
            return {'CANCELLED'} 