"""
TA Character Tools - 骨骼操作模块
作者: 2025Q3技术美术训练营_江一诺
描述: 处理角色骨骼相关操作，包括镜像、旋转、骨骼数据修正等
"""

import bpy
import math

class TA_OT_RotateReferenceObject(bpy.types.Operator):
    bl_idname = "ta.rotate_reference_object"
    bl_label = "旋转参考对象"
    bl_description = "参考对象先绕X轴旋转+90度，再绕Z轴旋转180度，并应用变换"

    def execute(self, context):
        ref_name = context.scene.ta_reference_object
        obj = bpy.data.objects.get(ref_name)
        if obj:
            obj.rotation_euler = (math.radians(90), 0, math.radians(180))
            # 设置为活动对象并选中
            bpy.context.view_layer.objects.active = obj
            obj.select_set(True)
            # 确保在对象模式
            if bpy.context.object.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            # 查找3D视图区域并用override调用
            for window in bpy.context.window_manager.windows:
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D':
                        for region in area.regions:
                            if region.type == 'WINDOW':
                                override = {
                                    'window': window,
                                    'screen': window.screen,
                                    'area': area,
                                    'region': region,
                                    'scene': context.scene,
                                    'active_object': obj,
                                    'selected_objects': [obj],
                                    'selected_editable_objects': [obj],
                                    'view_layer': context.view_layer,
                                }
                                bpy.ops.object.transform_apply(
                                    override,
                                    location=False, rotation=True, scale=False
                                )
                                self.report({'INFO'}, "已设置参考对象旋转为X+90°, Z+180°并应用变换")
                                return {'FINISHED'}
            self.report({'WARNING'}, "未找到3D视图区域，无法应用变换")
        else:
            self.report({'WARNING'}, "未找到参考对象")
        return {'FINISHED'}

class TA_OT_MirrorCharacterX(bpy.types.Operator):
    bl_idname = "ta.mirror_character_x"
    bl_label = "角色X轴镜像"
    bl_description = "角色X轴缩放设为-1并应用缩放"

    def execute(self, context):
        char_name = context.scene.ta_character_collection
        obj = bpy.data.objects.get(char_name)
        if obj:
            obj.scale[0] = -1
            bpy.context.view_layer.objects.active = obj
            obj.select_set(True)
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            # 修正法线
            if obj.type == 'MESH':
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.normals_make_consistent(inside=False)
                bpy.ops.object.mode_set(mode='OBJECT')
            self.report({'INFO'}, "已镜像并应用缩放，并修正法线")
        else:
            self.report({'WARNING'}, "未找到角色对象")
        return {'FINISHED'}

class TA_OT_FixMeshData(bpy.types.Operator):
    bl_idname = "ta.fix_mesh_data"
    bl_label = "一键修正骨骼数据"
    bl_description = "对角色和参考对象进行操作：删除冗余root骨骼，解锁所有connected骨骼"
    def execute(self, context):
        char_name = context.scene.ta_character_collection
        ref_name = context.scene.ta_reference_object
        char_obj = bpy.data.objects.get(char_name)
        ref_obj = bpy.data.objects.get(ref_name)
        # 骨骼修正
        for arm_obj in [char_obj, ref_obj]:
            if arm_obj and arm_obj.type == 'ARMATURE':
                # 先取消所有选中
                for obj in bpy.context.view_layer.objects:
                    obj.select_set(False)
                # 选中目标物体
                arm_obj.select_set(True)
                bpy.context.view_layer.objects.active = arm_obj
                bpy.ops.object.mode_set(mode='EDIT')
                edit_bones = arm_obj.data.edit_bones
                # 清理冗余root骨骼（只保留第一个root）
                root_bones = [b for b in edit_bones if b.parent is None]
                if len(root_bones) > 1:
                    for b in root_bones[1:]:
                        edit_bones.remove(b)
                # unlock所有connected骨骼
                for bone in edit_bones:
                    bone.use_connect = False
                    # _omit_命名的骨骼自动换成[omit]
                    if '_omit_' in bone.name:
                        bone.name = bone.name.replace('_omit_', '[omit]')
                bpy.ops.object.mode_set(mode='OBJECT')
        self.report({'INFO'}, "骨骼数据已修正")
        return {'FINISHED'}

class TA_OT_MatchEditPose(bpy.types.Operator):
    bl_idname = "ta.match_edit_pose"
    bl_label = "根据参考物体,重置edit bone"
    bl_description = "复制参考模型的骨架信息,重置角色edit bone匹配骨骼变换"
    def validate_armatures(self, context, char_obj, ref_obj):
        """验证骨架对象的有效性"""
        if not char_obj or not ref_obj:
            self.report({'ERROR'}, "未找到角色或参考骨架对象")
            return False
        if char_obj.type != 'ARMATURE' or ref_obj.type != 'ARMATURE':
            self.report({'ERROR'}, f"对象类型错误: 角色类型={char_obj.type}, 参考类型={ref_obj.type}")
            return False
        return True

    def enter_edit_mode(self, context, obj):
        """进入编辑模式"""
        for o in context.view_layer.objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='EDIT')
        return obj.data.edit_bones

    def match_bone_transforms(self, char_ebones, ref_ebones):
        """匹配骨骼变换"""
        matched_count = 0
        total_bones = len(char_ebones)
        
        # 获取根骨骼的相对位置差异
        char_root = None
        ref_root = None
        for bone in char_ebones:
            if bone.parent is None:
                char_root = bone
                break
        for bone in ref_ebones:
            if bone.parent is None:
                ref_root = bone
                break
                
        if char_root and ref_root:
            # 计算根骨骼的缩放比例
            char_scale = (char_root.tail - char_root.head).length
            ref_scale = (ref_root.tail - ref_root.head).length
            scale_factor = char_scale / ref_scale if ref_scale != 0 else 1.0
            
            # 遍历所有骨骼，保持相对位置关系
            for bone in char_ebones:
                if bone.name in ref_ebones:
                    ref_bone = ref_ebones[bone.name]
                    
                    if bone.parent:
                        # 对于子骨骼，保持与父骨骼的相对位置关系
                        parent_name = bone.parent.name
                        if parent_name in ref_ebones:
                            ref_parent = ref_ebones[parent_name]
                            
                            # 计算在参考骨架中的相对位置
                            ref_relative_head = ref_bone.head - ref_parent.head
                            ref_relative_tail = ref_bone.tail - ref_parent.head
                            
                            # 应用到角色骨架，保持缩放
                            bone.head = bone.parent.head + (ref_relative_head * scale_factor)
                            bone.tail = bone.parent.head + (ref_relative_tail * scale_factor)
                            bone.roll = ref_bone.roll
                    else:
                        # 对于根骨骼，保持原始位置，只调整方向和长度
                        original_head = bone.head.copy()
                        bone_vector = ref_bone.tail - ref_bone.head
                        bone_vector.normalize()
                        bone.tail = original_head + (bone_vector * (ref_bone.length * scale_factor))
                        bone.roll = ref_bone.roll
                        
                    matched_count += 1
                
        return matched_count, total_bones

    def execute(self, context):
        # 获取角色和参考对象
        char_name = context.scene.ta_character_collection
        ref_name = context.scene.ta_reference_object
        char_obj = bpy.data.objects.get(char_name)
        ref_obj = bpy.data.objects.get(ref_name)

        # 验证骨架
        if not self.validate_armatures(context, char_obj, ref_obj):
            return {'CANCELLED'}

        try:
            # 获取编辑骨骼
            char_ebones = self.enter_edit_mode(context, char_obj)
            ref_ebones = self.enter_edit_mode(context, ref_obj)
            
            # 匹配骨骼变换
            matched_count, total_bones = self.match_bone_transforms(char_ebones, ref_ebones)
            
            # 返回对象模式
            bpy.ops.object.mode_set(mode='OBJECT')
            
            # 报告结果
            self.report({'INFO'}, f"已完成骨骼匹配: {matched_count}/{total_bones} 个骨骼已更新")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"发生错误: {str(e)}")
            if context.object.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            return {'CANCELLED'} 