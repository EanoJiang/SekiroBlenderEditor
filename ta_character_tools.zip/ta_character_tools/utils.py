"""
TA Character Tools - 工具函数模块
作者: 2025Q3技术美术训练营_江一诺
描述: 提供插件使用的各种工具函数，包括路径更新、贴图导出等
"""

import bpy
import os
import json
import shutil
import re

def update_character_collection(self, context):
    name = context.scene.ta_character_name
    if name in bpy.data.collections:
        context.scene.ta_character_collection = name
        col = bpy.data.collections[name]
        # 取消所有选中
        for obj in bpy.context.view_layer.objects:
            obj.select_set(False)
        # 选中 collection 下的所有物体
        if col.objects:
            for obj in col.objects:
                obj.select_set(True)
            bpy.context.view_layer.objects.active = col.objects[0]
        auto_update_model_path(context)

def sync_character_name(self, context):
    context.scene.ta_character_name = context.scene.ta_character_collection

def update_project_path(self, context):
    auto_update_model_path(context)

def auto_update_model_path(context):
    project_path = context.scene.ta_project_path.strip().replace("\\", "/").rstrip("/")
    char_id = context.scene.ta_character_collection.strip()
    is_anim = context.scene.ta_is_anim
    if project_path and char_id and len(char_id) >= 5:
        char_prefix = char_id[:5]
        if is_anim:
            model_path = os.path.join(project_path, char_prefix, "Fbx", "Animation", f"{char_id}.fbx")
        else:
            model_path = os.path.join(project_path, char_prefix, "Fbx", f"{char_id}.fbx")
        # 路径
        model_path = os.path.normpath(model_path)
        context.scene.ta_model_path = model_path

def update_is_anim(self, context):
    auto_update_model_path(context)

def export_textures(context, char_id, project_path):
    # 1. 目标贴图目录
    char_prefix = char_id[:5]
    textures_dir = os.path.normpath(os.path.join(project_path, char_prefix, "Fbx", "Textures"))
    if not os.path.exists(textures_dir):
        os.makedirs(textures_dir, exist_ok=True)

    # 2. 解包所有贴图（如果有打包）
    try:
        bpy.ops.file.unpack_all(method='USE_LOCAL')
    except Exception as e:
        print(f"解包贴图失败: {e}")

    # 3. 收集所有图片贴图，只导出文件名中包含角色ID的贴图
    exported = set()
    base_name_map = {}

    for image in bpy.data.images:
        # 跳过没有文件路径且不是打包贴图的图片
        if not image.filepath and image.packed_file is None:
            continue

        img_name = os.path.basename(image.name)
        # 只导出文件名中包含角色ID的贴图
        if char_id not in img_name:
            continue

        # 取基础名（去掉 .001/.002/.003 等后缀）
        base_name = re.sub(r"\.00[0-9]$", "", img_name)
        save_path = os.path.join(textures_dir, base_name)

        # 只导出每个基础名的第一份
        if base_name in exported:
            continue

        # 如果是打包贴图，直接保存为PNG
        if image.packed_file is not None:
            try:
                image.filepath_raw = save_path
                image.file_format = 'PNG'
                image.save()
                exported.add(base_name)
            except Exception as e:
                print(f"保存打包贴图失败: {image.name} - {e}")
            continue

        # 绝对路径
        src_path = bpy.path.abspath(image.filepath)
        if os.path.exists(src_path):
            try:
                shutil.copy2(src_path, save_path)
                exported.add(base_name)
            except Exception as e:
                print(f"复制贴图失败: {src_path} - {e}") 