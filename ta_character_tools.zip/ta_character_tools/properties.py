"""
TA Character Tools - 属性定义模块
作者: 2025Q3技术美术训练营_江一诺
描述: 定义插件使用的自定义属性组和数据结构
"""

import bpy
import json
from . import utils

# 材质分组与分配数据结构
class TAMaterialGroupItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="分组名")
    material: bpy.props.StringProperty(
        name="分配材质",
        update=lambda self, context: self.apply_material(context)
    )
    mtd: bpy.props.StringProperty(name="MTD")
    
    def apply_material(self, context):
        if not self.material:
            return
            
        col_name = context.scene.ta_character_collection
        if col_name not in bpy.data.collections:
            return
            
        col = bpy.data.collections[col_name]
        mat_name = self.material
        
        if mat_name not in bpy.data.materials:
            return
            
        mat = bpy.data.materials[mat_name]
        part_names = self.name.split(',')
        
        for obj in col.objects:
            for part in part_names:
                if part and part in obj.name:
                    if hasattr(obj.data, 'materials'):
                        if len(obj.data.materials) == 0:
                            obj.data.materials.append(mat)
                        else:
                            for i in range(len(obj.data.materials)):
                                obj.data.materials[i] = mat
        
        # 保存材质分配信息
        material_assignments = {}
        if context.scene.ta_saved_material_assignments:
            try:
                material_assignments = json.loads(context.scene.ta_saved_material_assignments)
            except:
                pass
        
        parts_key = ','.join(sorted(self.name.split(',')))
        material_assignments[parts_key] = self.material
        context.scene.ta_saved_material_assignments = json.dumps(material_assignments) 